# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Animaquina-UR",
    "author" : "Luis Pacheco", 
    "description" : "An addon for robot  control and toolpathing",
    "blender" : (4, 2, 0),
    "version" : (0, 0, 4),
    "location" : "",
    "warning" : "Prealpha - Use at your own risk!",
    "doc_url": "www.animaquina.com", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import bpy, bmesh
import os
import time
import bmesh
from mathutils import Euler
import urx
import blf


addon_keymaps = {}
_icons = None
class dotdict(dict):
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


class SNA_OT_Disconnect__Xarm_B5347(bpy.types.Operator):
    bl_idname = "sna.disconnect__xarm_b5347"
    bl_label = "Disconnect  Xarm"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_B8CFE = disconnect()
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


class SNA_OT_Connect_Xarm_3Efab(bpy.types.Operator):
    bl_idname = "sna.connect_xarm_3efab"
    bl_label = "Connect Xarm"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_CE206 = connect()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Update_Pose_D5D92(bpy.types.Operator):
    bl_idname = "sna.update_pose_d5d92"
    bl_label = "update pose"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_4C5AF = update_pose()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Manualmode_Edd6D(bpy.types.Operator):
    bl_idname = "sna.manualmode_edd6d"
    bl_label = "manualmode"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_40C38 = manualMode()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Addmarker_2E3A1(bpy.types.Operator):
    bl_idname = "sna.addmarker_2e3a1"
    bl_label = "addmarker"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_99804 = addMarker()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_47Dfc(bpy.types.Operator):
    bl_idname = "sna.zero_47dfc"
    bl_label = "zero"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_67E4E = zero_all()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Jog_13671(bpy.types.Operator):
    bl_idname = "sna.jog_13671"
    bl_label = "jog"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_94F37 = jog()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Installsdk_F915B(bpy.types.Operator):
    bl_idname = "sna.installsdk_f915b"
    bl_label = "installsdk"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_SETUP_BBD40(bpy.types.Panel):
    bl_label = 'Setup'
    bl_idname = 'SNA_PT_SETUP_BBD40'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Animaquina'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_34D3E = layout.column(heading='Connect', align=True)
        col_34D3E.alert = False
        col_34D3E.enabled = True
        col_34D3E.active = True
        col_34D3E.use_property_split = False
        col_34D3E.use_property_decorate = False
        col_34D3E.scale_x = 1.0
        col_34D3E.scale_y = 1.0
        col_34D3E.alignment = 'Expand'.upper()
        col_34D3E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_34D3E.prop_search(bpy.context.scene, 'sna_robot', bpy.data, 'objects', text='Robot', icon='OBJECT_DATA')
        col_34D3E.prop(bpy.context.scene, 'sna_ip', text='IP ', icon_value=0, emboss=True, slider=False)
        op = col_34D3E.operator('sna.connect_xarm_3efab', text='Connect Robot', icon_value=0, emboss=True, depress=False)
        op = col_34D3E.operator('sna.disconnect__xarm_b5347', text='Disconnect Robot', icon_value=0, emboss=True, depress=False)
        col_7E02D = layout.column(heading='Cell', align=True)
        col_7E02D.alert = False
        col_7E02D.enabled = True
        col_7E02D.active = True
        col_7E02D.use_property_split = False
        col_7E02D.use_property_decorate = True
        col_7E02D.scale_x = 1.0
        col_7E02D.scale_y = 1.0
        col_7E02D.alignment = 'Expand'.upper()
        col_7E02D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"


class SNA_PT_TOOLPATHING_FDC9A(bpy.types.Panel):
    bl_label = 'Toolpathing'
    bl_idname = 'SNA_PT_TOOLPATHING_FDC9A'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Animaquina'
    bl_order = 2
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_B7431 = layout.column(heading='', align=True)
        col_B7431.alert = False
        col_B7431.enabled = True
        col_B7431.active = True
        col_B7431.use_property_split = False
        col_B7431.use_property_decorate = False
        col_B7431.scale_x = 1.0
        col_B7431.scale_y = 1.0
        col_B7431.alignment = 'Left'.upper()
        col_B7431.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_B7431.operator('sna.addmarker_2e3a1', text='Add Marker', icon_value=320, emboss=True, depress=False)
        op = col_B7431.operator('sna.runpath_c74d7', text='Path', icon_value=274, emboss=True, depress=False)
        op = col_B7431.operator('sna.debug_c0948', text='DEBUG', icon_value=30, emboss=True, depress=False)


class SNA_OT_Runpathold_D30Df(bpy.types.Operator):
    bl_idname = "sna.runpathold_d30df"
    bl_label = "Runpathold"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_4B1B0 = runPathold()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Debug_C0948(bpy.types.Operator):
    bl_idname = "sna.debug_c0948"
    bl_label = "debug"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_DD752 = debug()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


_C6C51_running = False
class SNA_OT_Realtime_C6C51(bpy.types.Operator):
    bl_idname = "sna.realtime_c6c51"
    bl_label = "realtime"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "CROSSHAIR"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceView3D':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _C6C51_running
        _C6C51_running = False
        context.window.cursor_set("DEFAULT")
        import math

        def before_modal():
            # Preparation code here
            print("Preparing for real-time armature updates...")
            bpy.context.scene.sna_realtime= True

        def modal():
            get_robotTCP()
            get_robotPose()
            update_twin_angles(bpy.context.scene.sna_robot.name )
            return {'PASS_THROUGH'}  # or {'FINISHED'} to end the modal operation

        def after_modal():
            print("Finished real-time armature updates.")
            bpy.context.scene.sna_realtime= False
            # Restore the original selection state, if necessary
            bpy.ops.object.select_all(action='DESELECT')
            for obj in bpy.context.selected_objects[:]:  # Assuming you stored these earlier
                obj.select_set(True)
            update_pose()
        return_F2A4B = after_modal()
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _C6C51_running
        if not context.area or not _C6C51_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('CROSSHAIR')
        try:
            import math

            def before_modal():
                # Preparation code here
                print("Preparing for real-time armature updates...")
                bpy.context.scene.sna_realtime= True

            def modal():
                get_robotTCP()
                get_robotPose()
                update_twin_angles(bpy.context.scene.sna_robot.name )
                return {'PASS_THROUGH'}  # or {'FINISHED'} to end the modal operation

            def after_modal():
                print("Finished real-time armature updates.")
                bpy.context.scene.sna_realtime= False
                # Restore the original selection state, if necessary
                bpy.ops.object.select_all(action='DESELECT')
                for obj in bpy.context.selected_objects[:]:  # Assuming you stored these earlier
                    obj.select_set(True)
                update_pose()
            return_C6C81 = modal()
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _C6C51_running
        if _C6C51_running:
            _C6C51_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            import math

            def before_modal():
                # Preparation code here
                print("Preparing for real-time armature updates...")
                bpy.context.scene.sna_realtime= True

            def modal():
                get_robotTCP()
                get_robotPose()
                update_twin_angles(bpy.context.scene.sna_robot.name )
                return {'PASS_THROUGH'}  # or {'FINISHED'} to end the modal operation

            def after_modal():
                print("Finished real-time armature updates.")
                bpy.context.scene.sna_realtime= False
                # Restore the original selection state, if necessary
                bpy.ops.object.select_all(action='DESELECT')
                for obj in bpy.context.selected_objects[:]:  # Assuming you stored these earlier
                    obj.select_set(True)
                update_pose()
            return_A1E74 = before_modal()
            context.window_manager.modal_handler_add(self)
            _C6C51_running = True
            return {'RUNNING_MODAL'}


_C74D7_running = False
class SNA_OT_Runpath_C74D7(bpy.types.Operator):
    bl_idname = "sna.runpath_c74d7"
    bl_label = "runPath"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "CROSSHAIR"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _C74D7_running
        _C74D7_running = False
        context.window.cursor_set("DEFAULT")
        from mathutils import Vector

        def prepare_paths():
            print("preparing path")
            obj = bpy.context.active_object
            if obj.mode == 'EDIT':
                bm = bmesh.from_edit_mesh(obj.data)
            else:
                bm = bmesh.new()
                bm.from_mesh(obj.data)
            vertices = [v for v in bm.verts]
            verts = [obj.matrix_world @ vert.co for vert in vertices]
        #    def are_connected(v1_index, v2_index):
        #        for edge in bm.edges:
        #            if vertices[v1_index] in edge.verts and vertices[v2_index] in edge.verts:
        #                return True
        #        return False
            paths = []
        #    new_segment = True
            for i, v in enumerate(verts):
                paths.append([v.x, v.y, v.z, bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c])
            if obj.mode != 'EDIT':
                bm.free()
            print("move 1")
            robot.movel(paths[0], acc, vel,wait=False)
            print("path prepared")
            return paths
        acc = 0.10
        vel = 0.10
        rad = 0.01 #radius/blend

        def modal_execute(paths):
            print("modal")
            print(paths)
        #    for path in paths:
        #        robot.movel(paths, acc, vel, rad)
            #robot.movels(paths, acc, vel, rad)
            robot.movexs('movel', paths, acc, vel, rad,wait=False)
            return {'FINISHED'}

        def cleanup():
            update_pose()
            print("Path Done!!")
            # Additional cleanup actions can be added here
        return_40068 = cleanup()
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _C74D7_running
        if not context.area or not _C74D7_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('CROSSHAIR')
        try:
            from mathutils import Vector

            def prepare_paths():
                print("preparing path")
                obj = bpy.context.active_object
                if obj.mode == 'EDIT':
                    bm = bmesh.from_edit_mesh(obj.data)
                else:
                    bm = bmesh.new()
                    bm.from_mesh(obj.data)
                vertices = [v for v in bm.verts]
                verts = [obj.matrix_world @ vert.co for vert in vertices]
            #    def are_connected(v1_index, v2_index):
            #        for edge in bm.edges:
            #            if vertices[v1_index] in edge.verts and vertices[v2_index] in edge.verts:
            #                return True
            #        return False
                paths = []
            #    new_segment = True
                for i, v in enumerate(verts):
                    paths.append([v.x, v.y, v.z, bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c])
                if obj.mode != 'EDIT':
                    bm.free()
                print("move 1")
                robot.movel(paths[0], acc, vel,wait=False)
                print("path prepared")
                return paths
            acc = 0.10
            vel = 0.10
            rad = 0.01 #radius/blend

            def modal_execute(paths):
                print("modal")
                print(paths)
            #    for path in paths:
            #        robot.movel(paths, acc, vel, rad)
                #robot.movels(paths, acc, vel, rad)
                robot.movexs('movel', paths, acc, vel, rad,wait=False)
                return {'FINISHED'}

            def cleanup():
                update_pose()
                print("Path Done!!")
                # Additional cleanup actions can be added here
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _C74D7_running
        if _C74D7_running:
            _C74D7_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            from mathutils import Vector

            def prepare_paths():
                print("preparing path")
                obj = bpy.context.active_object
                if obj.mode == 'EDIT':
                    bm = bmesh.from_edit_mesh(obj.data)
                else:
                    bm = bmesh.new()
                    bm.from_mesh(obj.data)
                vertices = [v for v in bm.verts]
                verts = [obj.matrix_world @ vert.co for vert in vertices]
            #    def are_connected(v1_index, v2_index):
            #        for edge in bm.edges:
            #            if vertices[v1_index] in edge.verts and vertices[v2_index] in edge.verts:
            #                return True
            #        return False
                paths = []
            #    new_segment = True
                for i, v in enumerate(verts):
                    paths.append([v.x, v.y, v.z, bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c])
                if obj.mode != 'EDIT':
                    bm.free()
                print("move 1")
                robot.movel(paths[0], acc, vel,wait=False)
                print("path prepared")
                return paths
            acc = 0.10
            vel = 0.10
            rad = 0.01 #radius/blend

            def modal_execute(paths):
                print("modal")
                print(paths)
            #    for path in paths:
            #        robot.movel(paths, acc, vel, rad)
                #robot.movels(paths, acc, vel, rad)
                robot.movexs('movel', paths, acc, vel, rad,wait=False)
                return {'FINISHED'}

            def cleanup():
                update_pose()
                print("Path Done!!")
                # Additional cleanup actions can be added here
            return_B03E7 = prepare_paths()
            return_69712 = modal_execute(return_B03E7)
            context.window_manager.modal_handler_add(self)
            _C74D7_running = True
            return {'RUNNING_MODAL'}


###setup


import sys
import math
from mathutils import Vector


def connect():
    global robot
    robot = urx.Robot(bpy.context.scene.sna_ip)
    update_pose()
    print("Conection Up")
    return robot


def disconnect():
    robot.close()
    armature_name = bpy.context.scene.sna_robot.name 
    tcp_name = bpy.context.scene.sna_tcp.name 
    armature_obj = bpy.data.objects.get(armature_name)
    for pb in armature_obj.pose.bones:
        pb.matrix_basis.identity()
        bpy.ops.pose.transforms_clear.poll()
    bpy.context.scene.sna_x = 0
    bpy.context.scene.sna_y = 0
    bpy.context.scene.sna_z = 0
    bpy.context.scene.sna_a = 0
    bpy.context.scene.sna_b = 0
    bpy.context.scene.sna_c = 0
    bpy.context.scene.sna_j1 = 0
    bpy.context.scene.sna_j2 = 0
    bpy.context.scene.sna_j3 = 0
    bpy.context.scene.sna_j4 = 0
    bpy.context.scene.sna_j5 = 0
    bpy.context.scene.sna_j6 = 0
    tcp_obj = bpy.data.objects.get(tcp_name)
    tcp_obj.location = [-1.18425 ,-0.2907 ,0.060844]
    tcp_obj.rotation_euler = [-math.pi/2,math.pi,math.pi]
    print("Robot Disconected")


def get_robotTCP():
    currentPos = robot.getl()
    bpy.context.scene.sna_x = currentPos[0]
    bpy.context.scene.sna_y = currentPos[1]
    bpy.context.scene.sna_z = currentPos[2]
    bpy.context.scene.sna_a = currentPos[3]
    bpy.context.scene.sna_b = currentPos[4]
    bpy.context.scene.sna_c = currentPos[5]
    print("TCP:")
    print(currentPos)


def get_robotPose(): # don't change!
    currentPose = robot.getj()
    bpy.context.scene.sna_j1 = math.degrees(currentPose[0])
    bpy.context.scene.sna_j2 = math.degrees(-currentPose[1])
    bpy.context.scene.sna_j3 = math.degrees(-currentPose[2])
    bpy.context.scene.sna_j4 = math.degrees(currentPose[3])
    bpy.context.scene.sna_j5 = math.degrees(-currentPose[4])
    bpy.context.scene.sna_j6 = math.degrees(currentPose[5])
    print("Pose:")
    print(currentPose)


def update_twin_angles(armature_name):
    # Update Angles
    joint_angles = [bpy.context.scene.sna_j1, bpy.context.scene.sna_j2, bpy.context.scene.sna_j3, bpy.context.scene.sna_j4, bpy.context.scene.sna_j5, bpy.context.scene.sna_j6]
    if len(joint_angles) > 6:
        joint_angles = joint_angles[:6]
    print(joint_angles)
    armature_obj = bpy.data.objects.get(armature_name)
    if armature_obj is None or armature_obj.type != 'ARMATURE':
        print(f"Armature named '{armature_name}' not found or not an armature.")
        return
    rotation_axes = ['Y', 'Z', 'Z', 'Y', 'Y', 'Y']  # Adjust if you have more joints
    for i, angle in enumerate(joint_angles):
        if i != 0 and i != 3 and i != 5:
            angle *= -1
        bone_name = f"joint_{i+1}"
        bone = armature_obj.pose.bones.get(bone_name)
        if bone:
            bone.rotation_mode = 'XYZ'
            axis = rotation_axes[i].upper()
            if axis == 'Y':
                bone.rotation_euler[1] = math.radians(angle)
            elif axis == 'Z':
                bone.rotation_euler[2] = math.radians(angle)
        else:
            print(f"No bone named '{bone_name}' found in armature '{armature_name}'.")
    # Update the scene to reflect changes
    bpy.context.view_layer.update()


def update_sim():  
    bpy.context.scene.sna_tcp.location[0] =  bpy.context.scene.sna_x 
    bpy.context.scene.sna_tcp.location[1] =   bpy.context.scene.sna_y
    bpy.context.scene.sna_tcp.location[2] =   bpy.context.scene.sna_z
    rpy = rv2rpy(bpy.context.scene.sna_a, bpy.context.scene.sna_b, bpy.context.scene.sna_c)
    bpy.context.scene.sna_tcp.rotation_euler[0] =   rpy[0]
    bpy.context.scene.sna_tcp.rotation_euler[1] =   rpy[1]
    bpy.context.scene.sna_tcp.rotation_euler[2] =   rpy[2]
    print("update sim: ")


def update_pose():
    get_robotTCP()
    get_robotPose()
    update_twin_angles(bpy.context.scene.sna_robot.name)
    update_sim()


def debug():
    print("Debug!")


#    text_name = "output.urp"
#    if text_name in bpy.data.texts:
#        content = bpy.data.texts[text_name].as_string()
#    else:
#        print(f"Text block '{text_name}' not found.")
#        return 0
#    robot.send_program(content)


def addMarker():
    update_pose()
    bpy.ops.object.empty_add(type='PLAIN_AXES',radius=.1,location=[bpy.context.scene.sna_x,bpy.context.scene.sna_y,bpy.context.scene.sna_z])  


def goTo():
    current_position = robot.getl()
    print(current_position)
    rv = rpy2rv(bpy.context.scene.sna_tcp.rotation_euler[0], bpy.context.scene.sna_tcp.rotation_euler[1], bpy.context.scene.sna_tcp.rotation_euler[2])
    newPos = [bpy.context.scene.sna_tcp.location[0],bpy.context.scene.sna_tcp.location[1],bpy.context.scene.sna_tcp.location[2],rv[0],rv[1], rv[2]] 
    print("new pos")
    print(newPos)
    robot.movel(newPos, 0.05, 0.05,wait=False)
    print("done")
    #update_pose() 


def manualMode():
    if bpy.context.scene.sna_manualmode == False:
        timeout = 60
        robot.send_program("def myProg():\n\tfreedrive_mode()\n\tsleep({})\nend".format(timeout))
        print("manual mode ON")
        bpy.context.scene.sna_manualmode= True
    else:
        robot.send_program("def myProg():\n\tend_freedrive_mode()\nend")
        print("manual mode OFF")
        bpy.context.scene.sna_manualmode= False


def rv2rpy(rx, ry, rz):
    theta = math.sqrt(rx*rx + ry*ry + rz*rz)
    if theta == 0:
        return [0, 0, 0]  # Return zero rotation if the vector is zero
    kx = rx / theta
    ky = ry / theta
    kz = rz / theta
    cth = math.cos(theta)
    sth = math.sin(theta)
    vth = 1 - math.cos(theta)
    r11 = kx*kx*vth + cth
    r12 = kx*ky*vth - kz*sth
    r13 = kx*kz*vth + ky*sth
    r21 = kx*ky*vth + kz*sth
    r22 = ky*ky*vth + cth
    r23 = ky*kz*vth - kx*sth
    r31 = kx*kz*vth - ky*sth
    r32 = ky*kz*vth + kx*sth
    r33 = kz*kz*vth + cth
    beta = math.atan2(-r31, math.sqrt(r11*r11 + r21*r21))
    if beta > d2r(89.99):
        beta = d2r(89.99)
        alpha = 0
        gamma = math.atan2(r12, r22)
    elif beta < -d2r(89.99):
        beta = -d2r(89.99)
        alpha = 0
        gamma = -math.atan2(r12, r22)
    else:
        cb = math.cos(beta)
        alpha = math.atan2(r21/cb, r11/cb)
        gamma = math.atan2(r32/cb, r33/cb)
    return [gamma, beta, alpha]


def rpy2rv(roll, pitch, yaw):
    alpha = yaw
    beta = pitch
    gamma = roll
    ca = math.cos(alpha)
    cb = math.cos(beta)
    cg = math.cos(gamma)
    sa = math.sin(alpha)
    sb = math.sin(beta)
    sg = math.sin(gamma)
    r11 = ca * cb
    r12 = ca * sb * sg - sa * cg
    r13 = ca * sb * cg + sa * sg
    r21 = sa * cb
    r22 = sa * sb * sg + ca * cg
    r23 = sa * sb * cg - ca * sg
    r31 = -sb
    r32 = cb * sg
    r33 = cb * cg
    theta = math.acos((r11 + r22 + r33 - 1) / 2)
    if abs(theta) < 1e-10:  # Check if theta is close to zero
        return [0, 0, 0]  # Return zero vector for identity rotation
    sth = math.sin(theta)
    kx = (r32 - r23) / (2 * sth)
    ky = (r13 - r31) / (2 * sth)
    kz = (r21 - r12) / (2 * sth)
    return [(theta * kx), (theta * ky), (theta * kz)]


def d2r(degrees):
    return degrees * math.pi / 180


_BCB48_running = False
class SNA_OT_Gototargetmod_Bcb48(bpy.types.Operator):
    bl_idname = "sna.gototargetmod_bcb48"
    bl_label = "goToTargetmod"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "CROSSHAIR"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not True or context.area.spaces[0].bl_rna.identifier == 'SpaceView3D':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _BCB48_running
        _BCB48_running = False
        context.window.cursor_set("DEFAULT")
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _BCB48_running
        if not context.area or not _BCB48_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.area.tag_redraw()
        context.window.cursor_set('CROSSHAIR')
        try:
            pass
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _BCB48_running
        if _BCB48_running:
            _BCB48_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            args = (context,)
            self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
            context.window_manager.modal_handler_add(self)
            _BCB48_running = True
            return {'RUNNING_MODAL'}


_746A0_running = False
class SNA_OT_Gotort_746A0(bpy.types.Operator):
    bl_idname = "sna.gotort_746a0"
    bl_label = "goToRT"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "CROSSHAIR"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _746A0_running
        _746A0_running = False
        context.window.cursor_set("DEFAULT")
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _746A0_running
        if not context.area or not _746A0_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('CROSSHAIR')
        try:
            pass
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _746A0_running
        if _746A0_running:
            _746A0_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            context.window_manager.modal_handler_add(self)
            _746A0_running = True
            return {'RUNNING_MODAL'}


class SNA_OT_Gototarget_2Cfb1(bpy.types.Operator):
    bl_idname = "sna.gototarget_2cfb1"
    bl_label = "goToTarget"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_AD7B0 = goTo()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


_A4C67_running = False
class SNA_OT_Testptp_A4C67(bpy.types.Operator):
    bl_idname = "sna.testptp_a4c67"
    bl_label = "testptp"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "CROSSHAIR"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _A4C67_running
        _A4C67_running = False
        context.window.cursor_set("DEFAULT")
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _A4C67_running
        if not context.area or not _A4C67_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('CROSSHAIR')
        try:
            pass
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _A4C67_running
        if _A4C67_running:
            _A4C67_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            context.window_manager.modal_handler_add(self)
            _A4C67_running = True
            return {'RUNNING_MODAL'}


class SNA_PT_COMMANDS_51755(bpy.types.Panel):
    bl_label = 'Commands'
    bl_idname = 'SNA_PT_COMMANDS_51755'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Animaquina'
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_1F9C7 = layout.column(heading='', align=True)
        col_1F9C7.alert = False
        col_1F9C7.enabled = True
        col_1F9C7.active = True
        col_1F9C7.use_property_split = False
        col_1F9C7.use_property_decorate = False
        col_1F9C7.scale_x = 1.0
        col_1F9C7.scale_y = 1.0
        col_1F9C7.alignment = 'Left'.upper()
        col_1F9C7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_1F9C7.label(text='Command', icon_value=0)
        op = col_1F9C7.operator('sna.update_pose_d5d92', text='Update Pose', icon_value=35, emboss=True, depress=False)
        op = col_1F9C7.operator('sna.manualmode_edd6d', text='Manual Mode', icon_value=778, emboss=True, depress=bpy.context.scene.sna_manualmode)
        op = col_1F9C7.operator('sna.realtime_c6c51', text='RealTime', icon_value=118, emboss=True, depress=bpy.context.scene.sna_realtime)
        col_1F9C7.prop(bpy.context.scene, 'sna_tcp', text='TARGET', icon_value=0, emboss=True)
        op = col_1F9C7.operator('sna.gototarget_2cfb1', text='goTarget', icon_value=274, emboss=True, depress=False)


class SNA_PT_INFO_4C39D(bpy.types.Panel):
    bl_label = 'Info'
    bl_idname = 'SNA_PT_INFO_4C39D'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Animaquina'
    bl_order = 3
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_00E0F = layout.column(heading='TCP position', align=True)
        col_00E0F.alert = False
        col_00E0F.enabled = True
        col_00E0F.active = True
        col_00E0F.use_property_split = False
        col_00E0F.use_property_decorate = False
        col_00E0F.scale_x = 1.0
        col_00E0F.scale_y = 1.0
        col_00E0F.alignment = 'Expand'.upper()
        col_00E0F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_00E0F.prop(bpy.context.scene, 'sna_x', text='X', icon_value=0, emboss=False, slider=True)
        col_00E0F.prop(bpy.context.scene, 'sna_y', text='Y', icon_value=0, emboss=False, slider=False)
        col_00E0F.prop(bpy.context.scene, 'sna_z', text='Z', icon_value=0, emboss=False)
        col_00E0F.prop(bpy.context.scene, 'sna_a', text='A', icon_value=0, emboss=False)
        col_00E0F.prop(bpy.context.scene, 'sna_b', text='B', icon_value=0, emboss=False)
        col_00E0F.prop(bpy.context.scene, 'sna_c', text='C', icon_value=0, emboss=False)
        col_9F6C0 = layout.column(heading='Joint Angles', align=True)
        col_9F6C0.alert = False
        col_9F6C0.enabled = True
        col_9F6C0.active = True
        col_9F6C0.use_property_split = False
        col_9F6C0.use_property_decorate = True
        col_9F6C0.scale_x = 1.0
        col_9F6C0.scale_y = 1.0
        col_9F6C0.alignment = 'Expand'.upper()
        col_9F6C0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_9F6C0.prop(bpy.context.scene, 'sna_j1', text='j1', icon_value=0, emboss=False)
        col_9F6C0.prop(bpy.context.scene, 'sna_j2', text='j2', icon_value=0, emboss=False)
        col_9F6C0.prop(bpy.context.scene, 'sna_j3', text='j3', icon_value=0, emboss=False)
        col_9F6C0.prop(bpy.context.scene, 'sna_j4', text='j4', icon_value=0, emboss=False)
        col_9F6C0.prop(bpy.context.scene, 'sna_j5', text='j5', icon_value=0, emboss=False)
        col_9F6C0.prop(bpy.context.scene, 'sna_j6', text='j6', icon_value=0, emboss=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_j1 = bpy.props.FloatProperty(name='j1', description='j1', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)
    bpy.types.Scene.sna_j2 = bpy.props.FloatProperty(name='j2', description='j2', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)
    bpy.types.Scene.sna_j3 = bpy.props.FloatProperty(name='j3', description='j3', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)
    bpy.types.Scene.sna_j4 = bpy.props.FloatProperty(name='j4', description='j4', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)
    bpy.types.Scene.sna_j5 = bpy.props.FloatProperty(name='j5', description='j5', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)
    bpy.types.Scene.sna_j6 = bpy.props.FloatProperty(name='j6', description='j6', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)
    bpy.types.Scene.sna_x = bpy.props.FloatProperty(name='X', description='', default=0.0, subtype='NONE', unit='NONE', step=100, precision=2)
    bpy.types.Scene.sna_y = bpy.props.FloatProperty(name='Y', description='', default=0.0, subtype='NONE', unit='NONE', step=100, precision=2)
    bpy.types.Scene.sna_z = bpy.props.FloatProperty(name='Z', description='', default=0.0, subtype='NONE', unit='NONE', step=100, precision=2)
    bpy.types.Scene.sna_a = bpy.props.FloatProperty(name='A', description='', default=0.0, subtype='NONE', unit='NONE', step=100, precision=2)
    bpy.types.Scene.sna_b = bpy.props.FloatProperty(name='B', description='', default=0.0, subtype='NONE', unit='NONE', step=100, precision=2)
    bpy.types.Scene.sna_c = bpy.props.FloatProperty(name='C', description='', default=0.0, subtype='NONE', unit='NONE', step=100, precision=2)
    bpy.types.Scene.sna_ip = bpy.props.StringProperty(name='IP', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_tcp = bpy.props.PointerProperty(name='tcp', description='', type=bpy.types.Object)
    bpy.types.Scene.sna_manualmode = bpy.props.BoolProperty(name='manualmode', description='', default=False)
    bpy.types.Scene.sna_tool = bpy.props.PointerProperty(name='tool', description='select tool', type=bpy.types.Object)
    bpy.types.Scene.sna_realtime = bpy.props.BoolProperty(name='realtime', description='', default=False)
    bpy.types.Scene.sna_robot = bpy.props.PointerProperty(name='robot', description='', type=bpy.types.Scene)
    bpy.utils.register_class(SNA_OT_Disconnect__Xarm_B5347)
    bpy.utils.register_class(SNA_OT_Connect_Xarm_3Efab)
    bpy.utils.register_class(SNA_OT_Update_Pose_D5D92)
    bpy.utils.register_class(SNA_OT_Manualmode_Edd6D)
    bpy.utils.register_class(SNA_OT_Addmarker_2E3A1)
    bpy.utils.register_class(SNA_OT_Zero_47Dfc)
    bpy.utils.register_class(SNA_OT_Jog_13671)
    bpy.utils.register_class(SNA_OT_Installsdk_F915B)
    bpy.utils.register_class(SNA_PT_SETUP_BBD40)
    bpy.utils.register_class(SNA_PT_TOOLPATHING_FDC9A)
    bpy.utils.register_class(SNA_OT_Runpathold_D30Df)
    bpy.utils.register_class(SNA_OT_Debug_C0948)
    bpy.utils.register_class(SNA_OT_Realtime_C6C51)
    bpy.utils.register_class(SNA_OT_Runpath_C74D7)
    bpy.utils.register_class(SNA_OT_Gototargetmod_Bcb48)
    bpy.utils.register_class(SNA_OT_Gotort_746A0)
    bpy.utils.register_class(SNA_OT_Gototarget_2Cfb1)
    bpy.utils.register_class(SNA_OT_Testptp_A4C67)
    bpy.utils.register_class(SNA_PT_COMMANDS_51755)
    bpy.utils.register_class(SNA_PT_INFO_4C39D)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_robot
    del bpy.types.Scene.sna_realtime
    del bpy.types.Scene.sna_tool
    del bpy.types.Scene.sna_manualmode
    del bpy.types.Scene.sna_tcp
    del bpy.types.Scene.sna_ip
    del bpy.types.Scene.sna_c
    del bpy.types.Scene.sna_b
    del bpy.types.Scene.sna_a
    del bpy.types.Scene.sna_z
    del bpy.types.Scene.sna_y
    del bpy.types.Scene.sna_x
    del bpy.types.Scene.sna_j6
    del bpy.types.Scene.sna_j5
    del bpy.types.Scene.sna_j4
    del bpy.types.Scene.sna_j3
    del bpy.types.Scene.sna_j2
    del bpy.types.Scene.sna_j1
    bpy.utils.unregister_class(SNA_OT_Disconnect__Xarm_B5347)
    bpy.utils.unregister_class(SNA_OT_Connect_Xarm_3Efab)
    bpy.utils.unregister_class(SNA_OT_Update_Pose_D5D92)
    bpy.utils.unregister_class(SNA_OT_Manualmode_Edd6D)
    bpy.utils.unregister_class(SNA_OT_Addmarker_2E3A1)
    bpy.utils.unregister_class(SNA_OT_Zero_47Dfc)
    bpy.utils.unregister_class(SNA_OT_Jog_13671)
    bpy.utils.unregister_class(SNA_OT_Installsdk_F915B)
    bpy.utils.unregister_class(SNA_PT_SETUP_BBD40)
    bpy.utils.unregister_class(SNA_PT_TOOLPATHING_FDC9A)
    bpy.utils.unregister_class(SNA_OT_Runpathold_D30Df)
    bpy.utils.unregister_class(SNA_OT_Debug_C0948)
    bpy.utils.unregister_class(SNA_OT_Realtime_C6C51)
    bpy.utils.unregister_class(SNA_OT_Runpath_C74D7)
    bpy.utils.unregister_class(SNA_OT_Gototargetmod_Bcb48)
    bpy.utils.unregister_class(SNA_OT_Gotort_746A0)
    bpy.utils.unregister_class(SNA_OT_Gototarget_2Cfb1)
    bpy.utils.unregister_class(SNA_OT_Testptp_A4C67)
    bpy.utils.unregister_class(SNA_PT_COMMANDS_51755)
    bpy.utils.unregister_class(SNA_PT_INFO_4C39D)
